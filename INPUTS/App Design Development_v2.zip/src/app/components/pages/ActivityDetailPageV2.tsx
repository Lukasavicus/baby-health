import { useState } from "react";
import { useNavigate } from "react-router";
import { Drawer } from "vaul";
import {
  ArrowLeft,
  Activity,
  Plus,
  Pencil,
  Trash2,
  X,
  Check,
  Star,
  ChevronDown,
  ChevronRight,
  // Category icons
  Heart,
  MessageCircle,
  BookOpen,
  Hand,
  Footprints,
  Brain,
  Smile,
  TreePine,
  // Activity icons
  Baby,
  Music,
  Eye,
  Ear,
  Move3d,
  Blocks,
  Palette,
  Puzzle,
  Shapes,
  Users,
  Sparkles,
  Sun,
  Droplets,
  Leaf,
  CloudRain,
} from "lucide-react";
import { TimePickerField } from "../TimePickerDialog";

// --- Comprehensive activity categories based on WHO/SBP research ---

interface ActivityOption {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description?: string;
}

interface ActivityCategory {
  id: string;
  label: string;
  color: string;
  bgColor: string;
  icon: React.ComponentType<{ className?: string }>;
  activities: ActivityOption[];
}

const activityCategories: ActivityCategory[] = [
  {
    id: "attachment",
    label: "Vínculo & Afeto",
    color: "text-pink-500",
    bgColor: "bg-baby-pink/30",
    icon: Heart,
    activities: [
      { id: "skin_contact", label: "Pele a pele", icon: Heart, description: "Contato pele a pele" },
      { id: "gentle_touch", label: "Toque suave", icon: Hand, description: "Massagem e carinho" },
      { id: "held_feeding", label: "Colo durante mamada", icon: Baby, description: "Olhar e conversar durante alimentação" },
      { id: "turn_taking", label: "Troca de turnos", icon: Smile, description: "Imitar sons e gestos do bebê" },
      { id: "calming", label: "Acalmar juntos", icon: Sparkles, description: "Estratégias de autorregulação" },
    ],
  },
  {
    id: "language",
    label: "Linguagem & Comunicação",
    color: "text-blue-500",
    bgColor: "bg-baby-blue/30",
    icon: MessageCircle,
    activities: [
      { id: "face_talk", label: "Conversa face a face", icon: MessageCircle, description: "Falar no nível dos olhos" },
      { id: "narrate", label: "Narrar ações", icon: MessageCircle, description: "Descrever o que está fazendo" },
      { id: "sound_imitation", label: "Imitar sons", icon: Ear, description: "Copiar e expandir sons do bebê" },
      { id: "name_objects", label: "Nomear objetos", icon: Eye, description: "Apontar e nomear o que o bebê olha" },
      { id: "songs_rhymes", label: "Canções e rimas", icon: Music, description: "Cantar com gestos" },
      { id: "simple_directions", label: "Instruções simples", icon: MessageCircle, description: "Pedidos de 2-3 passos" },
    ],
  },
  {
    id: "literacy",
    label: "Livros & Leitura",
    color: "text-indigo-500",
    bgColor: "bg-baby-lavender/30",
    icon: BookOpen,
    activities: [
      { id: "picture_book", label: "Livro de figuras", icon: BookOpen, description: "Olhar fotos coloridas juntos" },
      { id: "point_label", label: "Apontar e nomear", icon: Eye, description: "Identificar figuras no livro" },
      { id: "story_questions", label: "Perguntas da história", icon: Brain, description: "O que acontece depois?" },
      { id: "bedtime_reading", label: "Leitura antes de dormir", icon: BookOpen, description: "Rotina calma com 1-2 livros" },
    ],
  },
  {
    id: "sensory",
    label: "Exploração Sensorial",
    color: "text-amber-500",
    bgColor: "bg-baby-peach/30",
    icon: Sparkles,
    activities: [
      { id: "visual_tracking", label: "Rastrear visual", icon: Eye, description: "Mover objeto colorido lentamente" },
      { id: "texture_touch", label: "Texturas variadas", icon: Hand, description: "Explorar tecidos, objetos diferentes" },
      { id: "sound_making", label: "Fazer sons", icon: Music, description: "Chocalho, tambor, colher na panela" },
      { id: "safe_mouthing", label: "Exploração oral", icon: Baby, description: "Objetos seguros para levar à boca" },
      { id: "food_textures", label: "Texturas alimentares", icon: Sparkles, description: "Variedade de texturas na alimentação" },
      { id: "sensory_outdoor", label: "Sensorial ao ar livre", icon: Leaf, description: "Plantas, terra, água" },
    ],
  },
  {
    id: "fine_motor",
    label: "Motricidade Fina & Mão-Olho",
    color: "text-emerald-500",
    bgColor: "bg-baby-mint/30",
    icon: Hand,
    activities: [
      { id: "grasp_release", label: "Pegar e soltar", icon: Hand, description: "Agarrar e largar brinquedos" },
      { id: "container_play", label: "Colocar e tirar", icon: Blocks, description: "Objetos dentro/fora de caixas" },
      { id: "stacking", label: "Empilhar", icon: Blocks, description: "Blocos, copos, objetos" },
      { id: "shape_sorting", label: "Encaixar formas", icon: Shapes, description: "Classificar por forma" },
      { id: "puzzles", label: "Quebra-cabeças", icon: Puzzle, description: "Puzzles simples" },
      { id: "art_crayons", label: "Arte e rabiscos", icon: Palette, description: "Giz de cera grosso, tinta" },
      { id: "self_feeding", label: "Comer sozinho", icon: Baby, description: "Prática com colher e copo" },
      { id: "helper_tasks", label: "Tarefas de ajudante", icon: Hand, description: "Guardar objetos, levar guardanapo" },
    ],
  },
  {
    id: "gross_motor",
    label: "Motricidade Grossa & Ativo",
    color: "text-teal-500",
    bgColor: "bg-baby-mint/40",
    icon: Footprints,
    activities: [
      { id: "tummy_time", label: "Bruços", icon: Baby, description: "Tempo de barriga (30min/dia)" },
      { id: "rolling_reaching", label: "Rolar e alcançar", icon: Move3d, description: "Rolar para pegar brinquedos" },
      { id: "kicking_reaching", label: "Chutar e alcançar", icon: Footprints, description: "Jogos de chutar e alcançar" },
      { id: "crawl_chase", label: "Engatinhar e perseguir", icon: Footprints, description: "Jogos de engatinhar" },
      { id: "walk_run_climb", label: "Andar, correr, subir", icon: Footprints, description: "Movimentação livre" },
      { id: "ball_play", label: "Brincadeira com bola", icon: Move3d, description: "Rolar, chutar, perseguir bola" },
      { id: "dance_music", label: "Dançar com música", icon: Music, description: "Mover-se ao som de música" },
      { id: "go_games", label: "Jogos de movimento", icon: Footprints, description: "Preparar, apontar, já!" },
    ],
  },
  {
    id: "cognitive",
    label: "Cognitivo & Resolução de Problemas",
    color: "text-violet-500",
    bgColor: "bg-baby-lavender/40",
    icon: Brain,
    activities: [
      { id: "peekaboo", label: "Cadê? Achou!", icon: Eye, description: "Esconder e revelar rosto/objetos" },
      { id: "hide_find", label: "Esconder e achar", icon: Brain, description: "Esconder brinquedo sob pano" },
      { id: "cause_effect", label: "Causa e efeito", icon: Sparkles, description: "Apertar botão = algo acontece" },
      { id: "sorting", label: "Classificar", icon: Shapes, description: "Separar por cor/forma" },
      { id: "counting", label: "Contar objetos", icon: Brain, description: "Contar partes do corpo, degraus" },
      { id: "problem_solving", label: "Resolver problemas", icon: Puzzle, description: "Apoiar tentativas de solução" },
    ],
  },
  {
    id: "socioemotional",
    label: "Social-Emocional",
    color: "text-rose-500",
    bgColor: "bg-baby-pink/40",
    icon: Smile,
    activities: [
      { id: "label_feelings", label: "Nomear emoções", icon: Smile, description: "Dar palavras aos sentimentos" },
      { id: "gentle_rules", label: "Toque gentil e regras", icon: Heart, description: "Modelar toque suave" },
      { id: "praise_behavior", label: "Elogiar comportamento", icon: Star, description: "Reforço positivo" },
      { id: "empathy_talk", label: "Conversa sobre empatia", icon: Users, description: "Comentar emoções dos outros" },
      { id: "offer_choices", label: "Oferecer escolhas", icon: Sparkles, description: "Camiseta vermelha ou azul?" },
      { id: "peer_play", label: "Brincar com outras crianças", icon: Users, description: "Interação e divisão" },
    ],
  },
  {
    id: "nature",
    label: "Natureza & Ar Livre",
    color: "text-green-600",
    bgColor: "bg-green-100",
    icon: TreePine,
    activities: [
      { id: "outdoor_walk", label: "Passeio ao ar livre", icon: Sun, description: "Caminhada em área natural" },
      { id: "plant_contact", label: "Contato com plantas", icon: Leaf, description: "Tocar folhas, flores, grama" },
      { id: "water_play", label: "Brincar com água", icon: Droplets, description: "Com supervisão constante" },
      { id: "earth_play", label: "Brincar com terra", icon: TreePine, description: "Areia, terra, gravetos" },
      { id: "rain_play", label: "Brincar na chuva", icon: CloudRain, description: "Poças, barragens, barquinhos" },
      { id: "playground", label: "Parquinho", icon: Footprints, description: "Balanço, escorrega" },
      { id: "outdoor_picnic", label: "Piquenique", icon: Sun, description: "Comer ao ar livre em família" },
    ],
  },
];

// Flatten for icon lookup
const allActivities = activityCategories.flatMap((c) => c.activities);
const activityIconMap: Record<string, React.ComponentType<{ className?: string }>> = Object.fromEntries(
  allActivities.map((a) => [a.id, a.icon])
);
const activityLabelMap: Record<string, string> = Object.fromEntries(
  allActivities.map((a) => [a.id, a.label])
);

// --- Types ---
interface ActivityEntry {
  id: string;
  time: string;
  type: string;
  label: string;
  duration: number;
  notes: string;
}

const durationOptions = [5, 10, 15, 20, 30, 45, 60];

const initialLogs: ActivityEntry[] = [
  { id: "1", time: "09:30", type: "tummy_time", label: "Bruços", duration: 15, notes: "" },
  { id: "2", time: "10:15", type: "picture_book", label: "Livro de figuras", duration: 10, notes: "O Gato Xadrez" },
  { id: "3", time: "11:00", type: "container_play", label: "Colocar e tirar", duration: 15, notes: "Blocos na caixa" },
  { id: "4", time: "14:30", type: "outdoor_walk", label: "Passeio ao ar livre", duration: 30, notes: "Praça" },
  { id: "5", time: "16:00", type: "peekaboo", label: "Cadê? Achou!", duration: 5, notes: "" },
];

const weekData = [
  { day: "Seg", min: 65 },
  { day: "Ter", min: 80 },
  { day: "Qua", min: 45 },
  { day: "Qui", min: 70 },
  { day: "Sex", min: 55 },
  { day: "Sáb", min: 90 },
  { day: "Dom", min: 75 },
];

const maxMin = Math.max(...weekData.map((d) => d.min));

export function ActivityDetailPageV2() {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<ActivityEntry[]>(initialLogs);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<ActivityEntry | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(
    new Set(["tummy_time", "picture_book", "outdoor_walk", "container_play"])
  );

  // Form state
  const [formTime, setFormTime] = useState("");
  const [formType, setFormType] = useState("tummy_time");
  const [formDuration, setFormDuration] = useState(15);
  const [formNotes, setFormNotes] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [formStep, setFormStep] = useState<"select" | "details">("select");

  // Computed
  const totalMin = logs.reduce((s, l) => s + l.duration, 0);
  const sessionCount = logs.length;
  const uniqueTypes = new Set(logs.map((l) => l.type)).size;
  const categoriesUsed = new Set(
    logs.map((l) => {
      for (const cat of activityCategories) {
        if (cat.activities.some((a) => a.id === l.type)) return cat.id;
      }
      return "other";
    })
  ).size;

  const nowTime = () => {
    const n = new Date();
    return `${n.getHours().toString().padStart(2, "0")}:${n.getMinutes().toString().padStart(2, "0")}`;
  };

  const openNew = () => {
    setEditingEntry(null);
    setFormTime(nowTime());
    setFormType("tummy_time");
    setFormDuration(15);
    setFormNotes("");
    setFormStep("select");
    setDrawerOpen(true);
  };

  const openEdit = (entry: ActivityEntry) => {
    setEditingEntry(entry);
    setFormTime(entry.time);
    setFormType(entry.type);
    setFormDuration(entry.duration);
    setFormNotes(entry.notes);
    setFormStep("details");
    setDrawerOpen(true);
  };

  const handleSelectActivity = (actId: string) => {
    setFormType(actId);
    setFormStep("details");
  };

  const toggleFavorite = (actId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(actId)) next.delete(actId);
      else next.add(actId);
      return next;
    });
  };

  const toggleCategory = (catId: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(catId)) next.delete(catId);
      else next.add(catId);
      return next;
    });
  };

  const handleSave = () => {
    const label = activityLabelMap[formType] || "Atividade";
    const entry: ActivityEntry = {
      id: editingEntry?.id || Date.now().toString(),
      time: formTime,
      type: formType,
      label,
      duration: formDuration,
      notes: formNotes,
    };

    if (editingEntry) {
      setLogs(logs.map((l) => (l.id === entry.id ? entry : l)));
    } else {
      setLogs([entry, ...logs].sort((a, b) => a.time.localeCompare(b.time)));
    }
    setDrawerOpen(false);
  };

  const handleDelete = (id: string) => {
    setLogs(logs.filter((l) => l.id !== id));
    setDeleteConfirm(null);
  };

  const favoriteActivities = allActivities.filter((a) => favorites.has(a.id));

  return (
    <div className="pb-6">
      {/* Header */}
      <div className="px-5 pt-5 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-1">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2>Atividades (V2)</h2>
        </div>
        <button
          onClick={openNew}
          className="bg-baby-mint text-white w-9 h-9 rounded-full flex items-center justify-center active:scale-95 transition-transform"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Summary */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50 text-center">
          <p className="text-4xl text-baby-mint mb-1">{totalMin} min</p>
          <p className="text-xs text-muted-foreground">estimulação total hoje</p>
          <div className="flex justify-center gap-6 mt-4">
            <div>
              <p className="text-lg">{sessionCount}</p>
              <p className="text-[10px] text-muted-foreground">sessões</p>
            </div>
            <div>
              <p className="text-lg">{uniqueTypes}</p>
              <p className="text-[10px] text-muted-foreground">tipos</p>
            </div>
            <div>
              <p className="text-lg">{categoriesUsed}</p>
              <p className="text-[10px] text-muted-foreground">áreas</p>
            </div>
          </div>
        </div>
      </div>

      {/* Development areas touched today */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50">
          <p className="text-sm text-muted-foreground mb-3">Áreas estimuladas hoje</p>
          <div className="flex flex-wrap gap-2">
            {activityCategories.map((cat) => {
              const used = logs.some((l) => cat.activities.some((a) => a.id === l.type));
              const CatIcon = cat.icon;
              return (
                <div
                  key={cat.id}
                  className={`flex items-center gap-1.5 py-1.5 px-3 rounded-full text-[11px] transition-all ${
                    used
                      ? `${cat.bgColor} ${cat.color} ring-1 ring-current/20`
                      : "bg-secondary/50 text-muted-foreground/40"
                  }`}
                >
                  <CatIcon className="w-3.5 h-3.5" />
                  {cat.label.split(" ")[0]}
                  {used && <Check className="w-3 h-3" />}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Week chart */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50">
          <p className="text-sm text-muted-foreground mb-4">Minutos de atividade na semana</p>
          <div className="flex items-end justify-between gap-2 h-24">
            {weekData.map((d) => (
              <div key={d.day} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="w-full rounded-lg bg-baby-mint/60 transition-all"
                  style={{ height: `${(d.min / maxMin) * 100}%`, minHeight: 8 }}
                />
                <span className="text-[10px] text-muted-foreground">{d.day}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Today's log */}
      <div className="px-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50">
          <p className="text-sm text-muted-foreground mb-3">Registros de hoje</p>
          <div className="space-y-1">
            {logs.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-6">
                Nenhum registro ainda. Toque em + para adicionar.
              </p>
            )}
            {logs.map((l) => {
              const Icon = activityIconMap[l.type] || Activity;
              const cat = activityCategories.find((c) => c.activities.some((a) => a.id === l.type));
              return (
                <div key={l.id} className="flex items-start gap-3 py-2.5 group">
                  <span className="text-xs text-muted-foreground w-10 shrink-0 pt-1">{l.time}</span>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${cat?.bgColor || "bg-baby-mint/40"}`}>
                    <Icon className="w-4 h-4 text-foreground/60" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm truncate">{l.label}</p>
                      <span className="text-xs text-muted-foreground shrink-0 ml-2">{l.duration} min</span>
                    </div>
                    {l.notes && <p className="text-xs text-muted-foreground truncate">{l.notes}</p>}
                    {cat && (
                      <span className={`text-[10px] ${cat.color}/70`}>{cat.label}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(l)}
                      className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center"
                    >
                      <Pencil className="w-3 h-3 text-muted-foreground" />
                    </button>
                    {deleteConfirm === l.id ? (
                      <button
                        onClick={() => handleDelete(l.id)}
                        className="w-7 h-7 rounded-full bg-destructive/20 flex items-center justify-center"
                      >
                        <Check className="w-3 h-3 text-destructive" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirm(l.id)}
                        className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center"
                      >
                        <Trash2 className="w-3 h-3 text-muted-foreground" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Add/Edit Drawer */}
      <Drawer.Root open={drawerOpen} onOpenChange={setDrawerOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/30 z-40" />
          <Drawer.Content
            className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-3xl max-h-[92vh] mx-auto max-w-md"
            aria-describedby={undefined}
          >
            <Drawer.Title className="sr-only">
              {editingEntry ? "Editar" : "Nova"} Atividade
            </Drawer.Title>
            <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted mt-3 mb-2" />
            <div className="px-5 pb-8 overflow-y-auto max-h-[87vh]">
              <div className="flex items-center justify-between mb-5">
                <button
                  onClick={() => {
                    if (formStep === "details" && !editingEntry) {
                      setFormStep("select");
                    } else {
                      setDrawerOpen(false);
                    }
                  }}
                  className="p-1"
                >
                  <X className="w-5 h-5" />
                </button>
                <h3>
                  {formStep === "select"
                    ? "Escolher Atividade"
                    : editingEntry
                      ? "Editar Atividade"
                      : "Registrar Atividade"}
                </h3>
                <div className="w-5" />
              </div>

              {formStep === "select" ? (
                /* --- Activity Selection Step --- */
                <div className="space-y-4">
                  {/* Favorites section */}
                  {favoriteActivities.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
                        <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        Favoritos
                      </p>
                      <div className="space-y-1">
                        {favoriteActivities.map((a) => {
                          const AIcon = a.icon;
                          const cat = activityCategories.find((c) =>
                            c.activities.some((act) => act.id === a.id)
                          );
                          return (
                            <button
                              key={a.id}
                              onClick={() => handleSelectActivity(a.id)}
                              className={`w-full flex items-center gap-3 py-3 px-3.5 rounded-2xl transition-all active:scale-[0.98] ${cat?.bgColor || "bg-secondary"}`}
                            >
                              <div className="w-8 h-8 rounded-full bg-white/50 flex items-center justify-center shrink-0">
                                <AIcon className="w-4 h-4 text-foreground/60" />
                              </div>
                              <div className="flex-1 text-left">
                                <p className="text-sm">{a.label}</p>
                                {a.description && (
                                  <p className="text-[10px] text-muted-foreground">{a.description}</p>
                                )}
                              </div>
                              <span
                                role="button"
                                tabIndex={0}
                                onClick={(e) => toggleFavorite(a.id, e)}
                                onKeyDown={(e) => { if (e.key === 'Enter') toggleFavorite(a.id, e as any); }}
                                className="p-1 cursor-pointer"
                              >
                                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* All categories */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">
                      Todas as atividades
                    </p>
                    <div className="space-y-2">
                      {activityCategories.map((cat) => {
                        const CatIcon = cat.icon;
                        const isExpanded = expandedCategories.has(cat.id);
                        return (
                          <div key={cat.id} className="rounded-2xl overflow-hidden border border-border/30">
                            <button
                              onClick={() => toggleCategory(cat.id)}
                              className={`w-full flex items-center gap-3 py-3 px-3.5 transition-colors ${
                                isExpanded ? cat.bgColor : "bg-card"
                              }`}
                            >
                              <div className={`w-8 h-8 rounded-full ${cat.bgColor} flex items-center justify-center shrink-0`}>
                                <CatIcon className={`w-4 h-4 ${cat.color}`} />
                              </div>
                              <div className="flex-1 text-left">
                                <p className="text-sm">{cat.label}</p>
                                <p className="text-[10px] text-muted-foreground">
                                  {cat.activities.length} atividades
                                </p>
                              </div>
                              {isExpanded ? (
                                <ChevronDown className="w-4 h-4 text-muted-foreground" />
                              ) : (
                                <ChevronRight className="w-4 h-4 text-muted-foreground" />
                              )}
                            </button>

                            {isExpanded && (
                              <div className="px-2 pb-2 space-y-0.5">
                                {cat.activities.map((a) => {
                                  const AIcon = a.icon;
                                  const isFav = favorites.has(a.id);
                                  return (
                                    <button
                                      key={a.id}
                                      onClick={() => handleSelectActivity(a.id)}
                                      className="w-full flex items-center gap-3 py-2.5 px-3 rounded-xl hover:bg-secondary/50 transition-colors active:scale-[0.98]"
                                    >
                                      <div className={`w-7 h-7 rounded-full ${cat.bgColor} flex items-center justify-center shrink-0`}>
                                        <AIcon className="w-3.5 h-3.5 text-foreground/60" />
                                      </div>
                                      <div className="flex-1 text-left">
                                        <p className="text-xs">{a.label}</p>
                                        {a.description && (
                                          <p className="text-[10px] text-muted-foreground">
                                            {a.description}
                                          </p>
                                        )}
                                      </div>
                                      <span
                                        role="button"
                                        tabIndex={0}
                                        onClick={(e) => toggleFavorite(a.id, e)}
                                        onKeyDown={(e) => { if (e.key === 'Enter') toggleFavorite(a.id, e as any); }}
                                        className="p-1 cursor-pointer"
                                      >
                                        <Star
                                          className={`w-3.5 h-3.5 ${
                                            isFav
                                              ? "text-amber-400 fill-amber-400"
                                              : "text-muted-foreground/30"
                                          }`}
                                        />
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                /* --- Details Step --- */
                <div>
                  {/* Selected activity preview */}
                  {(() => {
                    const sel = allActivities.find((a) => a.id === formType);
                    const cat = activityCategories.find((c) =>
                      c.activities.some((a) => a.id === formType)
                    );
                    const SelIcon = sel?.icon || Activity;
                    return (
                      <div className={`flex items-center gap-3 p-3.5 rounded-2xl mb-5 ${cat?.bgColor || "bg-secondary"}`}>
                        <div className="w-10 h-10 rounded-full bg-white/50 flex items-center justify-center">
                          <SelIcon className={`w-5 h-5 ${cat?.color || "text-foreground/60"}`} />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm">{sel?.label || "Atividade"}</p>
                          {cat && <p className="text-[10px] text-muted-foreground">{cat.label}</p>}
                        </div>
                        {!editingEntry && (
                          <button
                            onClick={() => setFormStep("select")}
                            className="text-xs text-baby-mint underline"
                          >
                            Trocar
                          </button>
                        )}
                      </div>
                    );
                  })()}

                  {/* Horário */}
                  <div className="mb-5">
                    <label className="text-xs text-muted-foreground mb-2 block">Horário</label>
                    <TimePickerField value={formTime} onChange={setFormTime} />
                  </div>

                  {/* Duração */}
                  <div className="mb-5">
                    <label className="text-xs text-muted-foreground mb-2 block">Duração (min)</label>
                    <div className="flex gap-2 flex-wrap">
                      {durationOptions.map((d) => (
                        <button
                          key={d}
                          onClick={() => setFormDuration(d)}
                          className={`px-4 py-2.5 rounded-2xl text-xs transition-all ${
                            formDuration === d
                              ? "bg-baby-mint text-white shadow-sm"
                              : "bg-secondary text-foreground/60"
                          }`}
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Notas */}
                  <div className="mb-6">
                    <label className="text-xs text-muted-foreground mb-2 block">Observações</label>
                    <textarea
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      placeholder="Ex: Brincou com blocos, 2 livros..."
                      rows={3}
                      className="w-full bg-secondary rounded-2xl px-4 py-3 text-sm outline-none resize-none placeholder:text-muted-foreground/50"
                    />
                  </div>

                  {/* Save */}
                  <button
                    onClick={handleSave}
                    className="w-full py-3.5 rounded-2xl bg-baby-mint text-white text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
                  >
                    <Check className="w-4 h-4" />
                    {editingEntry ? "Salvar Alterações" : "Registrar"}
                  </button>
                </div>
              )}
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </div>
  );
}