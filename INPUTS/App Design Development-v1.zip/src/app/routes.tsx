import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { TodayPage } from "./components/pages/TodayPage";
import { CaregiversPage } from "./components/pages/CaregiversPage";
import { RoutinesPage } from "./components/pages/RoutinesPage";
import { MyBabyPage } from "./components/pages/MyBabyPage";
import { FeedingDetailPage } from "./components/pages/FeedingDetailPage";
import { HydrationDetailPage } from "./components/pages/HydrationDetailPage";
import { SleepDetailPage } from "./components/pages/SleepDetailPage";
import { DiaperDetailPage } from "./components/pages/DiaperDetailPage";
import { ActivityDetailPage } from "./components/pages/ActivityDetailPage";
import { ActivityDetailPageV2 } from "./components/pages/ActivityDetailPageV2";
import { BathDetailPage } from "./components/pages/BathDetailPage";
import { HealthDetailPage } from "./components/pages/HealthDetailPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: TodayPage },
      { path: "caregivers", Component: CaregiversPage },
      { path: "routines", Component: RoutinesPage },
      { path: "my-baby", Component: MyBabyPage },
      { path: "tracker/feeding", Component: FeedingDetailPage },
      { path: "tracker/hydration", Component: HydrationDetailPage },
      { path: "tracker/sleep", Component: SleepDetailPage },
      { path: "tracker/diaper", Component: DiaperDetailPage },
      { path: "tracker/activity", Component: ActivityDetailPage },
      { path: "tracker/activity-v2", Component: ActivityDetailPageV2 },
      { path: "tracker/bath", Component: BathDetailPage },
      { path: "tracker/health", Component: HealthDetailPage },
    ],
  },
]);