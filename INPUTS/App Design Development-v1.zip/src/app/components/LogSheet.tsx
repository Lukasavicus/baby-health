import { useState, useEffect } from "react";
import { Drawer } from "vaul";
import {
  Droplets, Moon, Activity,
  Milk, Minus, Plus, X, Check,
  BookOpen, Music, Baby as BabyIcon, Footprints, Eye, Ear, Move3d, TreePalm, MoreHorizontal,
  Bath, Pill, Syringe,
} from "lucide-react";
import { DiaperIcon } from "./DiaperIcon";

export type LogCategory = "feeding" | "hydration" | "sleep" | "diaper" | "activity" | "bath" | "health" | null;

const logTypes = [
  { id: "feeding" as const, label: "Alimentação", icon: Milk, color: "bg-baby-peach" },
  { id: "hydration" as const, label: "Hidratação", icon: Droplets, color: "bg-baby-blue" },
  { id: "sleep" as const, label: "Sono", icon: Moon, color: "bg-baby-lavender" },
  { id: "diaper" as const, label: "Fralda", icon: DiaperIcon, color: "bg-baby-yellow" },
  { id: "activity" as const, label: "Atividade", icon: Activity, color: "bg-baby-mint" },
  { id: "bath" as const, label: "Banho", icon: Bath, color: "bg-baby-blue" },
  { id: "health" as const, label: "Saúde", icon: Pill, color: "bg-baby-pink" },
];

const feedingTypes = [
  { id: "breast", label: "Amamentação" },
  { id: "bottle", label: "Mamadeira" },
  { id: "formula", label: "Fórmula" },
  { id: "solids", label: "Sólidos" },
];

const diaperTypes = [
  { id: "wet", label: "Xixi" },
  { id: "dirty", label: "Cocô" },
  { id: "mixed", label: "Misto" },
];

const activityTypes = [
  { id: "tummy", label: "Bruços", icon: BabyIcon },
  { id: "reading", label: "Leitura", icon: BookOpen },
  { id: "music", label: "Música", icon: Music },
  { id: "play", label: "Brincar", icon: Footprints },
  { id: "walk", label: "Passeio", icon: TreePalm },
  { id: "visual", label: "Est. Visual", icon: Eye },
  { id: "auditory", label: "Est. Auditivo", icon: Ear },
  { id: "spatial", label: "Est. Espacial", icon: Move3d },
  { id: "other", label: "Mais", icon: MoreHorizontal },
];

const sleepLocations = [
  { id: "crib", label: "Berço" },
  { id: "stroller", label: "Carrinho" },
  { id: "arms", label: "Colo" },
  { id: "car", label: "Carro" },
  { id: "bed", label: "Cama" },
];

const bathTemps = [
  { id: "warm", label: "🌡️ Morno" },
  { id: "lukewarm", label: "🌡️ Tépido" },
  { id: "cool", label: "❄️ Fresco" },
];

const healthSubTypes = [
  { id: "vitamin", label: "Vitamina" },
  { id: "medication", label: "Medicamento" },
];

interface LogSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onLog: (entry: any) => void;
  initialCategory?: LogCategory;
}

export function LogSheet({ open, onOpenChange, onLog, initialCategory = null }: LogSheetProps) {
  const [selected, setSelected] = useState<LogCategory>(null);
  const [subType, setSubType] = useState("");
  const [quantity, setQuantity] = useState(120);
  const [notes, setNotes] = useState("");
  // Sleep-specific
  const [sleepStart, setSleepStart] = useState("");
  const [sleepEnd, setSleepEnd] = useState("");
  const [sleepLocation, setSleepLocation] = useState("");
  // Activity-specific
  const [activityDuration, setActivityDuration] = useState(15);
  // Health-specific
  const [healthName, setHealthName] = useState("");
  const [healthDosage, setHealthDosage] = useState("");

  useEffect(() => {
    if (open) {
      setSelected(initialCategory);
      setSubType("");
      setQuantity(120);
      setNotes("");
      setSleepStart("");
      setSleepEnd("");
      setSleepLocation("");
      setActivityDuration(15);
      setHealthName("");
      setHealthDosage("");
    }
  }, [open, initialCategory]);

  const handleSave = () => {
    const now = new Date();
    const entry: any = {
      type: selected,
      subType,
      notes,
      time: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      timestamp: now,
      caregiver: "Mamãe",
    };
    if (selected === "feeding" || selected === "hydration") entry.quantity = quantity;
    if (selected === "sleep") {
      entry.sleepStart = sleepStart;
      entry.sleepEnd = sleepEnd;
      entry.sleepLocation = sleepLocation;
    }
    if (selected === "activity") entry.duration = activityDuration;
    if (selected === "health") {
      entry.healthName = healthName;
      entry.healthDosage = healthDosage;
    }
    onLog(entry);
    onOpenChange(false);
  };

  const handleBack = () => {
    if (initialCategory) {
      onOpenChange(false);
    } else {
      setSelected(null);
    }
  };

  const nowTime = () => {
    const n = new Date();
    return `${n.getHours().toString().padStart(2, "0")}:${n.getMinutes().toString().padStart(2, "0")}`;
  };

  const renderCategoryForm = () => {
    switch (selected) {
      case "feeding":
        return (
          <>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Tipo</p>
              <div className="flex flex-wrap gap-2">
                {feedingTypes.map((ft) => (
                  <button
                    key={ft.id}
                    onClick={() => setSubType(ft.id)}
                    className={`px-4 py-2 rounded-full text-sm transition-colors ${
                      subType === ft.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    {ft.label}
                  </button>
                ))}
              </div>
            </div>
            {(subType === "bottle" || subType === "formula") && (
              <QuantityPicker value={quantity} onChange={setQuantity} label="Quantidade (ml)" />
            )}
          </>
        );

      case "hydration":
        return <QuantityPicker value={quantity} onChange={setQuantity} label="Quantidade (ml)" />;

      case "sleep":
        return (
          <>
            <div className="mb-5 grid grid-cols-2 gap-3">
              <div>
                <p className="text-sm text-muted-foreground mb-1.5">Dormiu às</p>
                <input
                  type="time"
                  value={sleepStart || nowTime()}
                  onChange={(e) => setSleepStart(e.target.value)}
                  className="w-full bg-secondary rounded-xl p-3 text-sm outline-none"
                />
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1.5">Acordou às</p>
                <input
                  type="time"
                  value={sleepEnd}
                  onChange={(e) => setSleepEnd(e.target.value)}
                  className="w-full bg-secondary rounded-xl p-3 text-sm outline-none"
                />
              </div>
            </div>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Onde dormiu? (opcional)</p>
              <div className="flex flex-wrap gap-2">
                {sleepLocations.map((loc) => (
                  <button
                    key={loc.id}
                    onClick={() => setSleepLocation(sleepLocation === loc.id ? "" : loc.id)}
                    className={`px-4 py-2 rounded-full text-sm transition-colors ${
                      sleepLocation === loc.id
                        ? "bg-baby-lavender text-foreground"
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    {loc.label}
                  </button>
                ))}
              </div>
            </div>
          </>
        );

      case "diaper":
        return (
          <div className="mb-5">
            <p className="text-sm text-muted-foreground mb-2">Tipo</p>
            <div className="flex flex-wrap gap-2">
              {diaperTypes.map((dt) => (
                <button
                  key={dt.id}
                  onClick={() => setSubType(dt.id)}
                  className={`px-4 py-2 rounded-full text-sm transition-colors ${
                    subType === dt.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground"
                  }`}
                >
                  {dt.label}
                </button>
              ))}
            </div>
          </div>
        );

      case "activity":
        return (
          <>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-3">Tipo de atividade</p>
              <div className="grid grid-cols-4 gap-3">
                {activityTypes.map((at) => (
                  <button
                    key={at.id}
                    onClick={() => setSubType(at.id)}
                    className="flex flex-col items-center gap-1.5"
                  >
                    <div
                      className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                        subType === at.id
                          ? "bg-baby-mint/60"
                          : "bg-secondary"
                      }`}
                    >
                      <at.icon className={`w-6 h-6 ${subType === at.id ? "text-foreground" : "text-muted-foreground"}`} />
                    </div>
                    <span className="text-[10px] text-muted-foreground text-center leading-tight">{at.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Duração (min)</p>
              <div className="flex items-center gap-4 justify-center">
                <button
                  onClick={() => setActivityDuration(Math.max(5, activityDuration - 5))}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-3xl w-16 text-center">{activityDuration}</span>
                <button
                  onClick={() => setActivityDuration(activityDuration + 5)}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        );

      case "bath":
        return (
          <>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Temperatura</p>
              <div className="flex flex-wrap gap-2">
                {bathTemps.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSubType(t.id)}
                    className={`px-4 py-2 rounded-full text-sm transition-colors ${
                      subType === t.id
                        ? "bg-baby-blue text-foreground"
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Duração (min)</p>
              <div className="flex items-center gap-4 justify-center">
                <button
                  onClick={() => setActivityDuration(Math.max(5, activityDuration - 5))}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-3xl w-16 text-center">{activityDuration}</span>
                <button
                  onClick={() => setActivityDuration(activityDuration + 5)}
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        );

      case "health":
        return (
          <>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-2">Tipo</p>
              <div className="flex gap-2">
                {healthSubTypes.map((ht) => (
                  <button
                    key={ht.id}
                    onClick={() => setSubType(ht.id)}
                    className={`flex-1 py-2.5 rounded-full text-sm transition-colors ${
                      subType === ht.id
                        ? "bg-baby-pink text-foreground"
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    {ht.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-4">
              <p className="text-sm text-muted-foreground mb-1.5">Nome</p>
              <input
                type="text"
                value={healthName}
                onChange={(e) => setHealthName(e.target.value)}
                placeholder={subType === "vitamin" ? "Ex: Vitamina D, Ferro..." : "Ex: Paracetamol, Dipirona..."}
                className="w-full bg-secondary rounded-xl p-3 text-sm outline-none"
              />
            </div>
            <div className="mb-5">
              <p className="text-sm text-muted-foreground mb-1.5">Dosagem</p>
              <input
                type="text"
                value={healthDosage}
                onChange={(e) => setHealthDosage(e.target.value)}
                placeholder="Ex: 5 gotas, 2.5 ml, 1 comprimido..."
                className="w-full bg-secondary rounded-xl p-3 text-sm outline-none"
              />
            </div>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/30 z-40" />
        <Drawer.Content
          className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-3xl max-h-[85vh] mx-auto max-w-md"
          aria-describedby={undefined}
        >
          <Drawer.Title className="sr-only">Registrar</Drawer.Title>
          <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted mt-3 mb-2" />
          <div className="px-5 pb-8 overflow-y-auto max-h-[80vh]">
            {!selected ? (
              <>
                <h2 className="mb-5">Registrar</h2>
                <div className="grid grid-cols-3 gap-3">
                  {logTypes.map((t) => {
                    const IconComp = t.icon;
                    return (
                      <button
                        key={t.id}
                        onClick={() => setSelected(t.id)}
                        className={`${t.color} rounded-2xl p-4 flex flex-col items-center gap-2 transition-transform active:scale-95`}
                      >
                        <IconComp className="w-7 h-7 text-foreground/70" />
                        <span className="text-xs text-foreground/80">{t.label}</span>
                      </button>
                    );
                  })}
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between mb-5">
                  <button onClick={handleBack} className="p-1">
                    <X className="w-5 h-5" />
                  </button>
                  <h3>{logTypes.find((t) => t.id === selected)?.label}</h3>
                  <div className="w-5" />
                </div>

                {renderCategoryForm()}

                <div className="mb-6">
                  <p className="text-sm text-muted-foreground mb-2">Notas</p>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Adicionar nota..."
                    className="w-full bg-secondary rounded-xl p-3 text-sm resize-none h-20 outline-none"
                  />
                </div>

                <button
                  onClick={handleSave}
                  className="w-full bg-primary text-primary-foreground py-3.5 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
                >
                  <Check className="w-5 h-5" />
                  Salvar
                </button>
              </>
            )}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

function QuantityPicker({
  value,
  onChange,
  label,
}: {
  value: number;
  onChange: (v: number) => void;
  label: string;
}) {
  return (
    <div className="mb-5">
      <p className="text-sm text-muted-foreground mb-2">{label}</p>
      <div className="flex items-center gap-4 justify-center">
        <button
          onClick={() => onChange(Math.max(0, value - 30))}
          className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <Minus className="w-4 h-4" />
        </button>
        <span className="text-3xl w-20 text-center">{value}</span>
        <button
          onClick={() => onChange(value + 30)}
          className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}