import { Outlet, useNavigate, useLocation } from "react-router";
import { Heart, Users, BookOpen, Baby } from "lucide-react";

const tabs = [
  { path: "/", label: "Hoje", icon: Heart },
  { path: "/caregivers", label: "Cuidadores", icon: Users },
  { path: "/routines", label: "Rotinas", icon: BookOpen },
  { path: "/my-baby", label: "Meu Bebê", icon: Baby },
];

export function Layout() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background relative" style={{ fontFamily: "'Inter', sans-serif" }}>
      <div className="pb-20 overflow-y-auto">
        <Outlet />
      </div>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-md border-t border-border/50 z-40 max-w-md mx-auto">
        <div className="flex items-center justify-around py-2 px-2">
          {tabs.map((tab) => {
            const isActive = location.pathname === tab.path;
            return (
              <button
                key={tab.path}
                onClick={() => navigate(tab.path)}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <tab.icon className={`w-6 h-6 ${isActive ? "fill-primary/20" : ""}`} />
                <span className="text-[10px]">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
