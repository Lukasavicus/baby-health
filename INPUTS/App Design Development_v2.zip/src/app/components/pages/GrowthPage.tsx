import { useState } from "react";
import { useNavigate } from "react-router";
import { Drawer } from "vaul";
import {
  ArrowLeft,
  Plus,
  Weight,
  Ruler,
  CircleDot,
  X,
  Check,
  Pencil,
  Trash2,
  Info,
} from "lucide-react";
import {
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  ComposedChart,
} from "recharts";

// --- Types ---
type Metric = "weight" | "height" | "head";

interface GrowthEntry {
  id: string;
  date: string;
  weight: number;
  height: number;
  head: number;
}

const metricConfig: Record<
  Metric,
  {
    label: string;
    unit: string;
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    chartColor: string;
  }
> = {
  weight: {
    label: "Peso",
    unit: "kg",
    icon: Weight,
    color: "bg-baby-peach/40",
    chartColor: "#f4a261",
  },
  height: {
    label: "Altura",
    unit: "cm",
    icon: Ruler,
    color: "bg-baby-blue/40",
    chartColor: "#64b5f6",
  },
  head: {
    label: "Cabeça",
    unit: "cm",
    icon: CircleDot,
    color: "bg-baby-lavender/40",
    chartColor: "#ce93d8",
  },
};

// Simulated WHO percentile bands (simplified)
const percentileBands: Record<Metric, { month: number; p3: number; p15: number; p50: number; p85: number; p97: number }[]> = {
  weight: [
    { month: 0, p3: 2.5, p15: 2.9, p50: 3.3, p85: 3.7, p97: 4.2 },
    { month: 1, p3: 3.4, p15: 3.9, p50: 4.5, p85: 5.0, p97: 5.5 },
    { month: 2, p3: 4.3, p15: 4.9, p50: 5.6, p85: 6.3, p97: 6.9 },
    { month: 3, p3: 5.0, p15: 5.7, p50: 6.4, p85: 7.1, p97: 7.8 },
    { month: 4, p3: 5.6, p15: 6.3, p50: 7.0, p85: 7.7, p97: 8.4 },
    { month: 5, p3: 6.0, p15: 6.7, p50: 7.5, p85: 8.3, p97: 9.0 },
    { month: 6, p3: 6.4, p15: 7.1, p50: 7.9, p85: 8.7, p97: 9.5 },
    { month: 7, p3: 6.7, p15: 7.4, p50: 8.3, p85: 9.1, p97: 9.9 },
    { month: 8, p3: 7.0, p15: 7.7, p50: 8.6, p85: 9.4, p97: 10.3 },
    { month: 9, p3: 7.2, p15: 8.0, p50: 8.9, p85: 9.7, p97: 10.6 },
    { month: 10, p3: 7.4, p15: 8.2, p50: 9.1, p85: 10.0, p97: 10.9 },
    { month: 11, p3: 7.6, p15: 8.4, p50: 9.4, p85: 10.3, p97: 11.2 },
    { month: 12, p3: 7.8, p15: 8.6, p50: 9.6, p85: 10.5, p97: 11.5 },
  ],
  height: [
    { month: 0, p3: 46.1, p15: 47.5, p50: 49.9, p85: 52.0, p97: 53.7 },
    { month: 1, p3: 50.8, p15: 52.2, p50: 54.7, p85: 57.0, p97: 58.6 },
    { month: 2, p3: 54.4, p15: 55.9, p50: 58.4, p85: 60.8, p97: 62.4 },
    { month: 3, p3: 57.3, p15: 58.8, p50: 61.4, p85: 63.9, p97: 65.5 },
    { month: 4, p3: 59.7, p15: 61.2, p50: 63.9, p85: 66.4, p97: 68.0 },
    { month: 5, p3: 61.7, p15: 63.2, p50: 65.9, p85: 68.5, p97: 70.1 },
    { month: 6, p3: 63.3, p15: 64.9, p50: 67.6, p85: 70.3, p97: 71.9 },
    { month: 7, p3: 64.8, p15: 66.4, p50: 69.2, p85: 71.9, p97: 73.5 },
    { month: 8, p3: 66.2, p15: 67.8, p50: 70.6, p85: 73.3, p97: 75.0 },
    { month: 9, p3: 67.5, p15: 69.1, p50: 72.0, p85: 74.7, p97: 76.5 },
    { month: 10, p3: 68.7, p15: 70.4, p50: 73.3, p85: 76.1, p97: 77.9 },
    { month: 11, p3: 69.9, p15: 71.6, p50: 74.5, p85: 77.3, p97: 79.2 },
    { month: 12, p3: 71.0, p15: 72.8, p50: 75.7, p85: 78.6, p97: 80.5 },
  ],
  head: [
    { month: 0, p3: 32.1, p15: 33.0, p50: 34.5, p85: 35.7, p97: 36.7 },
    { month: 1, p3: 34.9, p15: 35.8, p50: 37.3, p85: 38.5, p97: 39.5 },
    { month: 2, p3: 36.8, p15: 37.7, p50: 39.1, p85: 40.3, p97: 41.3 },
    { month: 3, p3: 38.1, p15: 39.0, p50: 40.5, p85: 41.7, p97: 42.7 },
    { month: 4, p3: 39.2, p15: 40.1, p50: 41.6, p85: 42.8, p97: 43.8 },
    { month: 5, p3: 40.1, p15: 41.0, p50: 42.6, p85: 43.8, p97: 44.8 },
    { month: 6, p3: 40.9, p15: 41.8, p50: 43.3, p85: 44.6, p97: 45.6 },
    { month: 7, p3: 41.5, p15: 42.4, p50: 44.0, p85: 45.3, p97: 46.3 },
    { month: 8, p3: 42.0, p15: 43.0, p50: 44.5, p85: 45.8, p97: 46.9 },
    { month: 9, p3: 42.5, p15: 43.4, p50: 45.0, p85: 46.3, p97: 47.4 },
    { month: 10, p3: 42.9, p15: 43.8, p50: 45.4, p85: 46.7, p97: 47.8 },
    { month: 11, p3: 43.2, p15: 44.2, p50: 45.8, p85: 47.1, p97: 48.2 },
    { month: 12, p3: 43.5, p15: 44.5, p50: 46.1, p85: 47.4, p97: 48.5 },
  ],
};

const initialEntries: GrowthEntry[] = [
  { id: "1", date: "2025-08-05", weight: 3.3, height: 50, head: 34.5 },
  { id: "2", date: "2025-09-10", weight: 4.5, height: 54, head: 37 },
  { id: "3", date: "2025-10-15", weight: 5.6, height: 58, head: 39 },
  { id: "4", date: "2025-11-12", weight: 6.4, height: 61, head: 40.5 },
  { id: "5", date: "2025-12-10", weight: 7.0, height: 64, head: 41.5 },
  { id: "6", date: "2026-01-08", weight: 7.5, height: 66, head: 42.5 },
  { id: "7", date: "2026-02-05", weight: 7.9, height: 68, head: 43.5 },
  { id: "8", date: "2026-03-10", weight: 8.2, height: 70, head: 44 },
];

const timeFilters = ["3m", "6m", "1a", "Tudo"] as const;

export function GrowthPage() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState(initialEntries);
  const [activeMetric, setActiveMetric] = useState<Metric>("weight");
  const [timeFilter, setTimeFilter] = useState<(typeof timeFilters)[number]>("Tudo");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<GrowthEntry | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showPercentileInfo, setShowPercentileInfo] = useState(false);

  // Form
  const [formDate, setFormDate] = useState("");
  const [formWeight, setFormWeight] = useState("");
  const [formHeight, setFormHeight] = useState("");
  const [formHead, setFormHead] = useState("");

  const mc = metricConfig[activeMetric];
  const latest = entries[entries.length - 1];

  // Filter entries by time
  const filteredEntries = entries.filter((e) => {
    if (timeFilter === "Tudo") return true;
    const d = new Date(e.date);
    const now = new Date();
    const monthsBack = timeFilter === "3m" ? 3 : timeFilter === "6m" ? 6 : 12;
    const cutoff = new Date(now);
    cutoff.setMonth(cutoff.getMonth() - monthsBack);
    return d >= cutoff;
  });

  // Calculate baby age in months for each entry (birth: 2025-08-05)
  const birthDate = new Date(2025, 7, 5);
  const chartData = filteredEntries.map((e) => {
    const d = new Date(e.date);
    const months = (d.getFullYear() - birthDate.getFullYear()) * 12 + (d.getMonth() - birthDate.getMonth());
    return {
      month: months,
      label: `${months}m`,
      value: e[activeMetric],
    };
  });

  // Percentile band data for chart
  const bands = percentileBands[activeMetric];
  const minMonth = chartData.length ? Math.max(0, chartData[0].month - 1) : 0;
  const maxMonth = chartData.length ? chartData[chartData.length - 1].month + 1 : 12;
  const bandData = bands
    .filter((b) => b.month >= minMonth && b.month <= maxMonth)
    .map((b) => ({
      month: b.month,
      label: `${b.month}m`,
      p3: b.p3,
      p15: b.p15,
      p50: b.p50,
      p85: b.p85,
      p97: b.p97,
    }));

  // Merge baby data with band data
  const mergedData = bandData.map((b) => {
    const babyPoint = chartData.find((c) => c.month === b.month);
    return { ...b, baby: babyPoint?.value ?? null };
  });
  // Add any baby points not already in band months
  chartData.forEach((c) => {
    if (!mergedData.find((m) => m.month === c.month)) {
      const band = bands.find((b) => b.month === c.month);
      mergedData.push({
        month: c.month,
        label: c.label,
        p3: band?.p3 ?? 0,
        p15: band?.p15 ?? 0,
        p50: band?.p50 ?? 0,
        p85: band?.p85 ?? 0,
        p97: band?.p97 ?? 0,
        baby: c.value,
      });
    }
  });
  mergedData.sort((a, b) => a.month - b.month);

  // Current percentile estimate
  const latestMonth = chartData.length ? chartData[chartData.length - 1].month : 0;
  const latestValue = chartData.length ? chartData[chartData.length - 1].value : 0;
  const closestBand = bands.reduce((prev, curr) =>
    Math.abs(curr.month - latestMonth) < Math.abs(prev.month - latestMonth) ? curr : prev
  );
  const estimatePercentile = () => {
    if (latestValue <= closestBand.p3) return 3;
    if (latestValue <= closestBand.p15) return Math.round(3 + ((latestValue - closestBand.p3) / (closestBand.p15 - closestBand.p3)) * 12);
    if (latestValue <= closestBand.p50) return Math.round(15 + ((latestValue - closestBand.p15) / (closestBand.p50 - closestBand.p15)) * 35);
    if (latestValue <= closestBand.p85) return Math.round(50 + ((latestValue - closestBand.p50) / (closestBand.p85 - closestBand.p50)) * 35);
    if (latestValue <= closestBand.p97) return Math.round(85 + ((latestValue - closestBand.p85) / (closestBand.p97 - closestBand.p85)) * 12);
    return 97;
  };
  const percentile = estimatePercentile();

  const openNew = () => {
    setEditingEntry(null);
    setFormDate(new Date().toISOString().split("T")[0]);
    setFormWeight("");
    setFormHeight("");
    setFormHead("");
    setDrawerOpen(true);
  };

  const openEdit = (entry: GrowthEntry) => {
    setEditingEntry(entry);
    setFormDate(entry.date);
    setFormWeight(entry.weight.toString());
    setFormHeight(entry.height.toString());
    setFormHead(entry.head.toString());
    setDrawerOpen(true);
  };

  const handleSave = () => {
    const entry: GrowthEntry = {
      id: editingEntry?.id || Date.now().toString(),
      date: formDate,
      weight: parseFloat(formWeight) || 0,
      height: parseFloat(formHeight) || 0,
      head: parseFloat(formHead) || 0,
    };
    if (editingEntry) {
      setEntries(entries.map((e) => (e.id === entry.id ? entry : e)));
    } else {
      setEntries([...entries, entry].sort((a, b) => a.date.localeCompare(b.date)));
    }
    setDrawerOpen(false);
  };

  const handleDelete = (id: string) => {
    setEntries(entries.filter((e) => e.id !== id));
    setDeleteConfirm(null);
  };

  return (
    <div className="pb-6">
      {/* Header */}
      <div className="px-5 pt-5 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/my-baby")} className="p-1">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2>Crescimento</h2>
        </div>
        <button
          onClick={openNew}
          className="bg-primary text-white w-9 h-9 rounded-full flex items-center justify-center active:scale-95 transition-transform"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Metric tabs */}
      <div className="px-4 mb-4">
        <div className="flex gap-2">
          {(Object.keys(metricConfig) as Metric[]).map((m) => {
            const c = metricConfig[m];
            const Icon = c.icon;
            return (
              <button
                key={m}
                onClick={() => setActiveMetric(m)}
                className={`flex-1 py-3 rounded-2xl text-xs flex flex-col items-center gap-1.5 transition-all ${
                  activeMetric === m
                    ? `${c.color} ring-1 ring-border shadow-sm`
                    : "bg-secondary/60"
                }`}
              >
                <Icon className="w-4 h-4 text-foreground/60" />
                {c.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Current value summary */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50 text-center">
          <p className="text-4xl" style={{ color: mc.chartColor }}>
            {latest?.[activeMetric] ?? "--"}
            <span className="text-lg text-muted-foreground ml-1">{mc.unit}</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Ultima medicao
          </p>
          <div className="mt-3 flex items-center justify-center gap-2">
            <div className="w-24 h-2 rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${percentile}%`, backgroundColor: mc.chartColor }}
              />
            </div>
            <span className="text-xs text-muted-foreground">P{percentile}</span>
            <button onClick={() => setShowPercentileInfo(!showPercentileInfo)} className="p-0.5">
              <Info className="w-3.5 h-3.5 text-muted-foreground/50" />
            </button>
          </div>
          {showPercentileInfo && (
            <p className="text-[10px] text-muted-foreground mt-2 bg-secondary/50 rounded-xl p-2.5 text-left">
              O percentil indica a posicao do seu bebe em relacao a outras
              criancas da mesma idade. P{percentile} significa que o{" "}
              {mc.label.toLowerCase()} esta dentro da faixa esperada. Cada bebe
              cresce no seu proprio ritmo.
            </p>
          )}
        </div>
      </div>

      {/* Time filter */}
      <div className="px-4 mb-3">
        <div className="flex gap-2">
          {timeFilters.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeFilter(tf)}
              className={`px-3.5 py-1.5 rounded-full text-xs transition-all ${
                timeFilter === tf
                  ? "bg-primary text-white"
                  : "bg-secondary text-foreground/60"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Chart with percentile bands */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-4 shadow-sm border border-border/50">
          <p className="text-xs text-muted-foreground mb-3">
            {mc.label} ({mc.unit}) — com faixas de percentil
          </p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={mergedData} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: "#8E8E9A" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#8E8E9A" }}
                  axisLine={false}
                  tickLine={false}
                  domain={["auto", "auto"]}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: "1px solid rgba(0,0,0,0.08)",
                    fontSize: 12,
                    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                  }}
                />
                {/* Percentile bands */}
                <Area key="area-p97" dataKey="p97" fill="rgba(0,0,0,0.03)" stroke="none" />
                <Area key="area-p85" dataKey="p85" fill="rgba(0,0,0,0.03)" stroke="none" />
                <Area key="area-p50" dataKey="p50" fill="rgba(0,0,0,0.03)" stroke="none" />
                <Area key="area-p15" dataKey="p15" fill="rgba(0,0,0,0.02)" stroke="none" />
                <Area key="area-p3" dataKey="p3" fill="transparent" stroke="none" />
                {/* Percentile lines */}
                <Line key="line-p97" dataKey="p97" stroke="#e0e0e0" strokeWidth={1} strokeDasharray="4 4" dot={false} />
                <Line key="line-p50" dataKey="p50" stroke="#bdbdbd" strokeWidth={1} strokeDasharray="4 4" dot={false} />
                <Line key="line-p3" dataKey="p3" stroke="#e0e0e0" strokeWidth={1} strokeDasharray="4 4" dot={false} />
                {/* Baby line */}
                <Line
                  dataKey="baby"
                  stroke={mc.chartColor}
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: mc.chartColor, stroke: "#fff", strokeWidth: 2 }}
                  connectNulls
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-center gap-4 mt-2">
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-0.5 rounded-full" style={{ backgroundColor: mc.chartColor }} />
              <span className="text-[10px] text-muted-foreground">{mc.label}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-0.5 rounded-full bg-muted-foreground/20 border-dashed" />
              <span className="text-[10px] text-muted-foreground">P3 / P50 / P97</span>
            </div>
          </div>
        </div>
      </div>

      {/* History */}
      <div className="px-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50">
          <p className="text-sm text-muted-foreground mb-3">Historico de medicoes</p>
          <div className="space-y-1">
            {[...filteredEntries].reverse().map((e) => {
              const d = new Date(e.date);
              return (
                <div key={e.id} className="flex items-center gap-3 py-2.5 group">
                  <span className="text-xs text-muted-foreground w-16 shrink-0">
                    {d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
                  </span>
                  <div className="flex-1 flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <Weight className="w-3 h-3 text-muted-foreground/50" />
                      <span className="text-xs">{e.weight} kg</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Ruler className="w-3 h-3 text-muted-foreground/50" />
                      <span className="text-xs">{e.height} cm</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CircleDot className="w-3 h-3 text-muted-foreground/50" />
                      <span className="text-xs">{e.head} cm</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(e)}
                      className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center"
                    >
                      <Pencil className="w-3 h-3 text-muted-foreground" />
                    </button>
                    {deleteConfirm === e.id ? (
                      <button
                        onClick={() => handleDelete(e.id)}
                        className="w-7 h-7 rounded-full bg-destructive/20 flex items-center justify-center"
                      >
                        <Check className="w-3 h-3 text-destructive" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirm(e.id)}
                        className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center"
                      >
                        <Trash2 className="w-3 h-3 text-muted-foreground" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Add/Edit Drawer */}
      <Drawer.Root open={drawerOpen} onOpenChange={setDrawerOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/30 z-40" />
          <Drawer.Content
            className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-3xl max-h-[85vh] mx-auto max-w-md"
            aria-describedby={undefined}
          >
            <Drawer.Title className="sr-only">
              {editingEntry ? "Editar" : "Nova"} Medicao
            </Drawer.Title>
            <div className="mx-auto w-12 h-1.5 flex-shrink-0 rounded-full bg-muted mt-3 mb-2" />
            <div className="px-5 pb-8">
              <div className="flex items-center justify-between mb-6">
                <button onClick={() => setDrawerOpen(false)} className="p-1">
                  <X className="w-5 h-5" />
                </button>
                <h3>{editingEntry ? "Editar" : "Nova"} Medicao</h3>
                <div className="w-5" />
              </div>

              <div className="mb-4">
                <label className="text-xs text-muted-foreground mb-2 block">Data</label>
                <input
                  type="date"
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full bg-secondary rounded-2xl px-4 py-3 text-sm outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3 mb-6">
                <div>
                  <label className="text-xs text-muted-foreground mb-2 block">Peso (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formWeight}
                    onChange={(e) => setFormWeight(e.target.value)}
                    placeholder="8.2"
                    className="w-full bg-secondary rounded-2xl px-3 py-3 text-sm outline-none text-center"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-2 block">Altura (cm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formHeight}
                    onChange={(e) => setFormHeight(e.target.value)}
                    placeholder="70"
                    className="w-full bg-secondary rounded-2xl px-3 py-3 text-sm outline-none text-center"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-2 block">Cabeca (cm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formHead}
                    onChange={(e) => setFormHead(e.target.value)}
                    placeholder="44"
                    className="w-full bg-secondary rounded-2xl px-3 py-3 text-sm outline-none text-center"
                  />
                </div>
              </div>

              <button
                onClick={handleSave}
                className="w-full py-3.5 rounded-2xl bg-primary text-white text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
              >
                <Check className="w-4 h-4" />
                {editingEntry ? "Salvar" : "Registrar"}
              </button>
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </div>
  );
}