import { useState } from "react";
import {
  TrendingUp, Ruler, Weight, CircleDot, Pill, Heart,
  ChevronRight, Star, Calendar,
} from "lucide-react";

const milestones = [
  { age: "6m", title: "Senta sem apoio", done: true },
  { age: "7m", title: "Engatinha", done: true },
  { age: "8m", title: "Puxa para ficar de pé", done: false },
  { age: "9m", title: "Primeiras palavras", done: false },
  { age: "10m", title: "Aponta para objetos", done: false },
];

const growthData = [
  { label: "Peso", value: "8.2 kg", icon: Weight, color: "bg-baby-peach/40" },
  { label: "Altura", value: "70 cm", icon: Ruler, color: "bg-baby-blue/40" },
  { label: "Cabeça", value: "44 cm", icon: CircleDot, color: "bg-baby-lavender/40" },
];

const medications = [
  { name: "Vitamina D", dose: "400 UI", time: "08:00", taken: true },
  { name: "Ferro", dose: "1mg/kg", time: "12:00", taken: false },
];

export function MyBabyPage() {
  const [medState, setMedState] = useState(medications);

  const toggleMed = (idx: number) => {
    setMedState((prev) =>
      prev.map((m, i) => (i === idx ? { ...m, taken: !m.taken } : m))
    );
  };

  return (
    <div className="pb-6">
      <div className="px-5 pt-6 pb-4">
        <h1>Meu Bebê</h1>
      </div>

      {/* Baby Profile Card */}
      <div className="px-4 mb-4">
        <div className="bg-card rounded-3xl p-5 shadow-sm border border-border/50 flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-baby-peach/50 flex items-center justify-center text-3xl">
            👶
          </div>
          <div>
            <h2>Liam</h2>
            <p className="text-sm text-muted-foreground">8 meses · nascido em 05/08/2025</p>
          </div>
        </div>
      </div>

      {/* Weekly Report */}
      <div className="px-4 mb-4">
        <div className="bg-gradient-to-br from-primary/15 to-baby-blue/20 rounded-3xl p-5 border border-primary/10">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              <p className="text-sm">Relatório semanal</p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <p className="text-xl">28</p>
              <p className="text-[10px] text-muted-foreground">refeições</p>
            </div>
            <div className="text-center">
              <p className="text-xl">14h</p>
              <p className="text-[10px] text-muted-foreground">sono/dia</p>
            </div>
            <div className="text-center">
              <p className="text-xl">5x</p>
              <p className="text-[10px] text-muted-foreground">fraldas/dia</p>
            </div>
          </div>
        </div>
      </div>

      {/* Growth */}
      <div className="px-4 mb-4">
        <h3 className="mb-3">Crescimento</h3>
        <div className="grid grid-cols-3 gap-3">
          {growthData.map((g) => (
            <div key={g.label} className="bg-card rounded-2xl p-4 shadow-sm border border-border/50 text-center">
              <div className={`w-10 h-10 rounded-full ${g.color} flex items-center justify-center mx-auto mb-2`}>
                <g.icon className="w-5 h-5 text-foreground/50" />
              </div>
              <p className="text-lg">{g.value}</p>
              <p className="text-[10px] text-muted-foreground">{g.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Milestones */}
      <div className="px-4 mb-4">
        <h3 className="mb-3">Marcos do desenvolvimento</h3>
        <div className="bg-card rounded-3xl p-4 shadow-sm border border-border/50 space-y-3">
          {milestones.map((m, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${m.done ? "bg-primary/20" : "bg-secondary"}`}>
                {m.done ? (
                  <Star className="w-4 h-4 text-primary" />
                ) : (
                  <div className="w-3 h-3 rounded-full border-2 border-muted-foreground/30" />
                )}
              </div>
              <div className="flex-1">
                <p className={`text-sm ${m.done ? "" : "text-muted-foreground"}`}>{m.title}</p>
                <p className="text-[10px] text-muted-foreground">{m.age}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Medications */}
      <div className="px-4 mb-4">
        <h3 className="mb-3">Vitaminas & Medicações</h3>
        <div className="space-y-3">
          {medState.map((m, i) => (
            <div key={i} className="bg-card rounded-2xl p-4 shadow-sm border border-border/50 flex items-center gap-3">
              <button
                onClick={() => toggleMed(i)}
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                  m.taken ? "bg-primary/20" : "bg-secondary"
                }`}
              >
                <Pill className={`w-5 h-5 ${m.taken ? "text-primary" : "text-muted-foreground"}`} />
              </button>
              <div className="flex-1">
                <p className="text-sm">{m.name}</p>
                <p className="text-[10px] text-muted-foreground">{m.dose} · {m.time}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${m.taken ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`}>
                {m.taken ? "Tomou" : "Pendente"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
