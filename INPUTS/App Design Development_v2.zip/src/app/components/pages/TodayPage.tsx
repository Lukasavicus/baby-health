import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Milk,
  Droplets,
  Moon,
  Activity,
  Plus,
  Sparkles,
  BookOpen,
  Baby as BabyIcon,
  Footprints,
  Eye,
  Bath,
  Pill,
  Syringe,
  ShieldPlus,
  Heart,
  Hand,
  CupSoda,
  UtensilsCrossed,
  Clock,
  Check,
  Brain,
  TreePine,
  Smile,
} from "lucide-react";
import { TrackerCard } from "../TrackerCard";
import { AwakeWindow } from "../AwakeWindow";
import { Timeline } from "../Timeline";
import { LogSheet, type LogCategory } from "../LogSheet";
import { BabyCoreTile } from "../BabyCoreTile";
import { DiaperIcon } from "../DiaperIcon";

const mockEntries = [
  {
    type: "feeding",
    subType: "breast",
    time: "07:15",
    caregiver: "Mamãe",
    notes: "Amamentou bem",
  },
  {
    type: "diaper",
    subType: "wet",
    time: "07:45",
    caregiver: "Papai",
  },
  {
    type: "sleep",
    subType: "",
    time: "08:30",
    caregiver: "Mamãe",
    notes: "Cochilo de 40min",
  },
  {
    type: "feeding",
    subType: "solids",
    time: "10:00",
    caregiver: "Vovó",
    notes: "Banana e aveia",
  },
  {
    type: "hydration",
    subType: "",
    time: "10:30",
    caregiver: "Vovó",
    quantity: 60,
  },
  {
    type: "activity",
    subType: "tummy",
    time: "11:00",
    caregiver: "Papai",
    notes: "15 min",
  },
  {
    type: "diaper",
    subType: "dirty",
    time: "11:30",
    caregiver: "Papai",
  },
];

const insights = [
  "O cochilo da manhã costuma ser entre 8h e 9h.",
  "Hidratação tende a cair à tarde — lembre-se de oferecer água!",
  "A ingestão de leite está mais forte pela manhã.",
];

const quickActivities = [
  { id: "tummy", label: "Bruços", icon: BabyIcon },
  { id: "reading", label: "Leitura", icon: BookOpen },
  { id: "play", label: "Brincar", icon: Footprints },
  { id: "visual", label: "Estímulo", icon: Eye },
];

const quickVitamins = [
  { id: "vitd", label: "Vit. D" },
  { id: "iron", label: "Ferro" },
];

const quickMeds = [
  { id: "paracetamol", label: "Paracet." },
  { id: "dipirona", label: "Dipirona" },
];

// V2 data: tracks taken status with time
const vitaminItems = [
  { id: "vitd", label: "Vit. D", takenAt: "08:00" },
  { id: "iron", label: "Ferro", takenAt: null as string | null },
];

const medItems = [
  { id: "paracetamol", label: "Paracetamol", takenAt: null as string | null },
  { id: "dipirona", label: "Dipirona", takenAt: null as string | null },
];

export function TodayPage() {
  const navigate = useNavigate();
  const [logOpen, setLogOpen] = useState(false);
  const [logCategory, setLogCategory] =
    useState<LogCategory>(null);
  const [logSubType, setLogSubType] = useState("");
  const [entries, setEntries] = useState(mockEntries);
  const [water, setWater] = useState(180);
  const [insightIdx] = useState(
    Math.floor(Math.random() * insights.length),
  );
  const [isSleeping, setIsSleeping] = useState(false);
  const [lastWakeTime, setLastWakeTime] = useState<Date>(
    new Date(Date.now() - 5400000),
  );

  // V2 health tile state
  const [vitaminsV2, setVitaminsV2] = useState(vitaminItems);
  const [medsV2, setMedsV2] = useState(medItems);

  const handleToggleVitamin = (id: string) => {
    setVitaminsV2((prev) =>
      prev.map((v) =>
        v.id === id
          ? {
              ...v,
              takenAt: v.takenAt
                ? null
                : new Date().toLocaleTimeString("pt-BR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  }),
            }
          : v,
      ),
    );
  };

  const handleToggleMed = (id: string) => {
    setMedsV2((prev) =>
      prev.map((m) =>
        m.id === id
          ? {
              ...m,
              takenAt: m.takenAt
                ? null
                : new Date().toLocaleTimeString("pt-BR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  }),
            }
          : m,
      ),
    );
  };

  const openLog = (category: LogCategory = null, subType = "") => {
    setLogCategory(category);
    setLogSubType(subType);
    setLogOpen(true);
  };

  const handleLog = (entry: any) => {
    setEntries([entry, ...entries]);
    if (entry.type === "hydration")
      setWater(water + (entry.quantity || 60));
  };

  const handleToggleSleep = () => {
    const now = new Date();
    const time = now.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });

    if (isSleeping) {
      // Baby woke up
      handleLog({
        type: "sleep",
        subType: "wake",
        time,
        timestamp: now,
        caregiver: "Mamãe",
        notes: "Bebê acordou",
      });
      setLastWakeTime(now);
    } else {
      // Baby fell asleep
      handleLog({
        type: "sleep",
        subType: "asleep",
        time,
        timestamp: now,
        caregiver: "Mamãe",
        notes: "Bebê dormiu",
      });
    }
    setIsSleeping(!isSleeping);
  };

  const handleQuickActivity = (actId: string) => {
    openLog("activity", actId);
  };

  const handleQuickFeeding = (type: string) => {
    openLog("feeding", type);
  };

  const today = new Date();
  const dayName = today.toLocaleDateString("pt-BR", {
    weekday: "long",
  });
  const dateStr = today.toLocaleDateString("pt-BR", {
    day: "numeric",
    month: "long",
  });

  return (
    <div className="pb-6">
      {/* Header */}
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-baby-mint">Baby Health</h1>
        <p className="text-sm text-muted-foreground capitalize">
          {dayName}, {dateStr}
        </p>
      </div>

      {/* Baby Core Tile */}
      <div className="px-4 mb-4">
        <BabyCoreTile />
      </div>

      {/* Insight */}
      <div className="px-4 mb-4">
        <div className="bg-baby-mint/10 border border-baby-mint/20 rounded-2xl p-4 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-baby-mint shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            {insights[insightIdx]}
          </p>
        </div>
      </div>

      {/* Awake Window + Sleep toggle */}
      <div className="px-4 mb-4">
        <AwakeWindow
          lastWake={lastWakeTime}
          isSleeping={isSleeping}
          onToggleSleep={handleToggleSleep}
        />
      </div>

      {/* Tracker Cards */}
      <div className="px-4 space-y-4 mb-6">
        {/* Feeding with quick options */}
        <TrackerCard
          icon={Milk}
          title="Alimentação"
          value="4"
          subtitle="refeições hoje"
          color="bg-baby-peach/40"
          onAction={() => openLog("feeding")}
          onTap={() => navigate("/tracker/feeding")}
        >
          <div className="flex gap-2 mt-3 pt-3 border-t border-border/30">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleQuickFeeding("breast_l");
              }}
              className="flex-1 bg-baby-peach/30 text-foreground/70 py-2 rounded-xl text-xs active:scale-95 transition-transform flex items-center justify-center gap-1"
            >
              <Hand className="w-3 h-3 inline mr-1" />Esq
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleQuickFeeding("breast_r");
              }}
              className="flex-1 bg-baby-peach/30 text-foreground/70 py-2 rounded-xl text-xs active:scale-95 transition-transform flex items-center justify-center gap-1"
            >
              <Hand className="w-3 h-3 inline mr-1" />Dir
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleQuickFeeding("bottle");
              }}
              className="flex-1 bg-baby-peach/30 text-foreground/70 py-2 rounded-xl text-xs active:scale-95 transition-transform flex items-center justify-center gap-1"
            >
              <CupSoda className="w-3 h-3 inline mr-1" />Mamad.
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleQuickFeeding("solids");
              }}
              className="flex-1 bg-baby-peach/30 text-foreground/70 py-2 rounded-xl text-xs active:scale-95 transition-transform flex items-center justify-center gap-1"
            >
              <UtensilsCrossed className="w-3 h-3 inline mr-1" />Sólidos
            </button>
          </div>
        </TrackerCard>

        <TrackerCard
          icon={Droplets}
          title="Hidratação"
          value={`${water}`}
          subtitle="/500 ml"
          color="bg-baby-blue/40"
          progress={(water / 500) * 100}
          onAction={() => openLog("hydration")}
          onTap={() => navigate("/tracker/hydration")}
        />

        <TrackerCard
          icon={Moon}
          title="Sono"
          value="2h40"
          subtitle="total hoje"
          color="bg-baby-lavender/40"
          onAction={() => openLog("sleep")}
          onTap={() => navigate("/tracker/sleep")}
        />

        <TrackerCard
          icon={DiaperIcon}
          title="Fraldas"
          value="3"
          subtitle="trocas hoje"
          color="bg-baby-yellow/40"
          onAction={() => openLog("diaper")}
          onTap={() => navigate("/tracker/diaper")}
        />

        {/* Activities with quick action grid (V1) */}
        <TrackerCard
          icon={Activity}
          title="Atividades"
          value="2"
          subtitle="sessões hoje"
          color="bg-baby-mint/40"
          onAction={() => openLog("activity")}
          onTap={() => navigate("/tracker/activity")}
        >
          <div className="flex gap-3 mt-3 pt-3 border-t border-border/30">
            {quickActivities.map((qa) => (
              <button
                key={qa.id}
                onClick={(e) => {
                  e.stopPropagation();
                  handleQuickActivity(qa.id);
                }}
                className="flex-1 flex flex-col items-center gap-1 active:scale-95 transition-transform"
              >
                <div className="w-10 h-10 rounded-full bg-baby-mint/30 flex items-center justify-center">
                  <qa.icon className="w-4 h-4 text-foreground/60" />
                </div>
                <span className="text-[10px] text-muted-foreground">
                  {qa.label}
                </span>
              </button>
            ))}
          </div>
        </TrackerCard>

        {/* V2: Activities with developmental categories */}
        <TrackerCard
          icon={Activity}
          title="Atividades (V2)"
          value="5"
          subtitle="sessões hoje"
          color="bg-baby-mint/40"
          onAction={() => openLog("activity")}
          onTap={() => navigate("/tracker/activity-v2")}
        >
          <div className="mt-3 pt-3 border-t border-border/30">
            <p className="text-[10px] text-muted-foreground mb-2">Áreas estimuladas</p>
            <div className="flex flex-wrap gap-1.5">
              {[
                { label: "Vínculo", icon: Heart, color: "text-pink-500", bg: "bg-baby-pink/30", active: true },
                { label: "Linguagem", icon: BookOpen, color: "text-blue-500", bg: "bg-baby-blue/30", active: true },
                { label: "Motor", icon: Footprints, color: "text-teal-500", bg: "bg-baby-mint/40", active: true },
                { label: "Cognitivo", icon: Brain, color: "text-violet-500", bg: "bg-baby-lavender/30", active: false },
                { label: "Social", icon: Smile, color: "text-rose-500", bg: "bg-baby-pink/20", active: false },
                { label: "Natureza", icon: TreePine, color: "text-green-600", bg: "bg-green-100", active: true },
              ].map((area) => (
                <div
                  key={area.label}
                  className={`flex items-center gap-1 py-1 px-2 rounded-full text-[10px] transition-all ${
                    area.active
                      ? `${area.bg} ${area.color}`
                      : "bg-secondary/50 text-muted-foreground/40"
                  }`}
                >
                  <area.icon className="w-3 h-3" />
                  {area.label}
                  {area.active && <Check className="w-2.5 h-2.5" />}
                </div>
              ))}
            </div>
          </div>
        </TrackerCard>

        {/* Bath */}
        <TrackerCard
          icon={Bath}
          title="Banho"
          value="1"
          subtitle="banho hoje"
          color="bg-baby-blue/40"
          onAction={() => openLog("bath")}
          onTap={() => navigate("/tracker/bath")}
        />

        {/* Vitamins & Medications */}
        <TrackerCard
          icon={Pill}
          title="Vitaminas & Medicamentos"
          value="2"
          subtitle="doses hoje"
          color="bg-baby-pink/40"
          onAction={() => openLog("health")}
          onTap={() => navigate("/tracker/health")}
        >
          <div className="mt-3 pt-3 border-t border-border/30">
            <div className="flex gap-4">
              {/* Vitamins column */}
              <div className="flex-1">
                <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-baby-mint/30 flex items-center justify-center bg-[#ffb7b266]">
                    <ShieldPlus className="w-3 h-3 text-pink-400" />
                  </span>
                  Vitaminas
                </p>
                <div className="flex flex-col gap-1.5">
                  {quickVitamins.map((v) => (
                    <button
                      key={v.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        const now = new Date();
                        handleLog({
                          type: "health",
                          subType: "vitamin",
                          time: now.toLocaleTimeString(
                            "pt-BR",
                            {
                              hour: "2-digit",
                              minute: "2-digit",
                            },
                          ),
                          timestamp: now,
                          caregiver: "Mamãe",
                          notes: v.label,
                          healthName: v.label,
                        });
                      }}
                      className="bg-baby-pink/20 text-foreground/70 py-2 px-3 rounded-xl text-xs active:scale-95 transition-transform text-left"
                    >
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Divider */}
              <div className="w-px bg-border/50" />

              {/* Medications column */}
              <div className="flex-1">
                <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-baby-pink/40 flex items-center justify-center">
                    <Heart className="w-3 h-3 text-pink-400" />
                  </span>
                  Medicamentos
                </p>
                <div className="flex flex-col gap-1.5">
                  {quickMeds.map((m) => (
                    <button
                      key={m.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        const now = new Date();
                        handleLog({
                          type: "health",
                          subType: "medication",
                          time: now.toLocaleTimeString(
                            "pt-BR",
                            {
                              hour: "2-digit",
                              minute: "2-digit",
                            },
                          ),
                          timestamp: now,
                          caregiver: "Mamãe",
                          notes: m.label,
                          healthName: m.label,
                        });
                      }}
                      className="bg-baby-pink/20 text-foreground/70 py-2 px-3 rounded-xl text-xs active:scale-95 transition-transform text-left"
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </TrackerCard>

        {/* V2: Vitamins & Medications — quick status view */}
        <TrackerCard
          icon={Pill}
          title="Vitaminas & Meds (V2)"
          value={`${vitaminsV2.filter((v) => v.takenAt).length + medsV2.filter((m) => m.takenAt).length}`}
          subtitle={`/${vitaminsV2.length + medsV2.length} doses`}
          color="bg-baby-pink/40"
          progress={
            ((vitaminsV2.filter((v) => v.takenAt).length +
              medsV2.filter((m) => m.takenAt).length) /
              (vitaminsV2.length + medsV2.length)) *
            100
          }
          onAction={() => openLog("health")}
          onTap={() => navigate("/tracker/health")}
        >
          <div className="mt-3 pt-3 border-t border-border/30 space-y-3">
            {/* Vitamins */}
            <div>
              <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-[#ffb7b266] flex items-center justify-center">
                  <ShieldPlus className="w-3 h-3 text-pink-400" />
                </span>
                Vitaminas
              </p>
              <div className="flex flex-col gap-2">
                {vitaminsV2.map((v) => (
                  <button
                    key={v.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleVitamin(v.id);
                    }}
                    className={`flex items-center justify-between py-2.5 px-3.5 rounded-2xl text-xs transition-all active:scale-[0.98] ${
                      v.takenAt
                        ? "bg-baby-pink/50 ring-1 ring-baby-pink/60"
                        : "bg-baby-pink/15"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                          v.takenAt
                            ? "bg-baby-pink/70"
                            : "bg-baby-pink/25"
                        }`}
                      >
                        {v.takenAt ? (
                          <Check className="w-3.5 h-3.5 text-white" />
                        ) : (
                          <Pill className="w-3 h-3 text-foreground/40" />
                        )}
                      </div>
                      <span
                        className={
                          v.takenAt
                            ? "text-foreground/90"
                            : "text-foreground/60"
                        }
                      >
                        {v.label}
                      </span>
                    </div>
                    {v.takenAt ? (
                      <span className="flex items-center gap-1 text-[10px] text-foreground/60 bg-white/50 py-0.5 px-2 rounded-full">
                        <Clock className="w-3 h-3" />
                        {v.takenAt}
                      </span>
                    ) : (
                      <span className="text-[10px] text-foreground/35">
                        Toque para registrar
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Medications */}
            <div>
              <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-baby-pink/40 flex items-center justify-center">
                  <Heart className="w-3 h-3 text-pink-400" />
                </span>
                Medicamentos
              </p>
              <div className="flex flex-col gap-2">
                {medsV2.map((m) => (
                  <button
                    key={m.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleMed(m.id);
                    }}
                    className={`flex items-center justify-between py-2.5 px-3.5 rounded-2xl text-xs transition-all active:scale-[0.98] ${
                      m.takenAt
                        ? "bg-baby-lavender/50 ring-1 ring-baby-lavender/60"
                        : "bg-baby-lavender/15"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                          m.takenAt
                            ? "bg-baby-lavender/70"
                            : "bg-baby-lavender/25"
                        }`}
                      >
                        {m.takenAt ? (
                          <Check className="w-3.5 h-3.5 text-white" />
                        ) : (
                          <Syringe className="w-3 h-3 text-foreground/40" />
                        )}
                      </div>
                      <span
                        className={
                          m.takenAt
                            ? "text-foreground/90"
                            : "text-foreground/60"
                        }
                      >
                        {m.label}
                      </span>
                    </div>
                    {m.takenAt ? (
                      <span className="flex items-center gap-1 text-[10px] text-foreground/60 bg-white/50 py-0.5 px-2 rounded-full">
                        <Clock className="w-3 h-3" />
                        {m.takenAt}
                      </span>
                    ) : (
                      <span className="text-[10px] text-foreground/35">
                        Toque para registrar
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </TrackerCard>
      </div>

      {/* Timeline */}
      <div className="px-4">
        <Timeline
          entries={entries}
          onEdit={(index) => {
            // Open log sheet pre-filled for that entry type
            const entry = entries[index];
            if (entry) openLog(entry.type as LogCategory, entry.subType);
          }}
          onDelete={(index) => {
            setEntries(entries.filter((_, i) => i !== index));
          }}
        />
      </div>

      {/* FAB - generic register */}
      <button
        onClick={() => openLog(null)}
        className="fixed bottom-24 right-5 w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center z-30 active:scale-90 transition-transform"
      >
        <Plus className="w-7 h-7" />
      </button>

      <LogSheet
        open={logOpen}
        onOpenChange={setLogOpen}
        onLog={handleLog}
        initialCategory={logCategory}
        initialSubType={logSubType}
      />
    </div>
  );
}