import { BookOpen, Music, Moon, Sun, Apple, Play } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const routines = [
  {
    id: "tummy",
    title: "Tempo de Bruços",
    subtitle: "Fortalece pescoço e ombros",
    duration: "5-15 min",
    color: "from-baby-mint/30 to-baby-blue/20",
    icon: Sun,
  },
  {
    id: "reading",
    title: "Hora da Leitura",
    subtitle: "Estimula linguagem e vínculo",
    duration: "10-20 min",
    color: "from-baby-lavender/30 to-baby-pink/20",
    icon: BookOpen,
  },
  {
    id: "sleep-routine",
    title: "Rotina do Sono",
    subtitle: "Banho, livro, música, sono",
    duration: "30 min",
    color: "from-baby-blue/30 to-baby-lavender/20",
    icon: Moon,
  },
  {
    id: "play",
    title: "Brincadeira Livre",
    subtitle: "Exploração e desenvolvimento motor",
    duration: "15-30 min",
    color: "from-baby-peach/30 to-baby-yellow/20",
    icon: Play,
  },
  {
    id: "feeding-guide",
    title: "Guia de Alimentação",
    subtitle: "Introdução alimentar por idade",
    duration: "Consulta",
    color: "from-baby-peach/40 to-baby-mint/20",
    icon: Apple,
  },
  {
    id: "music",
    title: "Música e Cantigas",
    subtitle: "Estímulo auditivo e calma",
    duration: "10 min",
    color: "from-baby-pink/30 to-baby-lavender/20",
    icon: Music,
  },
];

const articles = [
  { title: "Como criar uma rotina de sono saudável", tag: "Sono", mins: 5 },
  { title: "Introdução alimentar: guia completo", tag: "Alimentação", mins: 8 },
  { title: "Atividades para desenvolvimento motor", tag: "Atividades", mins: 4 },
];

export function RoutinesPage() {
  return (
    <div className="pb-6">
      <div className="px-5 pt-6 pb-4">
        <h1>Rotinas</h1>
        <p className="text-sm text-muted-foreground">Guias e rotinas para o bebê</p>
      </div>

      {/* Featured */}
      <div className="px-4 mb-5">
        <div className="bg-gradient-to-br from-primary/15 to-baby-lavender/20 rounded-3xl p-5 border border-primary/10">
          <p className="text-xs text-primary mb-1">Destaque</p>
          <h3>Rotina do sono para 8 meses</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Aprenda a criar uma rotina noturna calma e consistente para seu bebê.
          </p>
          <button className="mt-3 bg-primary text-primary-foreground px-5 py-2 rounded-full text-sm">
            Começar
          </button>
        </div>
      </div>

      {/* Routine Cards Grid */}
      <div className="px-4 mb-6">
        <h3 className="mb-3">Rotinas guiadas</h3>
        <div className="grid grid-cols-2 gap-3">
          {routines.map((r) => (
            <button
              key={r.id}
              className={`bg-gradient-to-br ${r.color} rounded-2xl p-4 text-left border border-border/30 active:scale-[0.97] transition-transform`}
            >
              <r.icon className="w-6 h-6 text-foreground/50 mb-2" />
              <p className="text-sm">{r.title}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{r.subtitle}</p>
              <p className="text-[10px] text-primary mt-2">{r.duration}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Articles */}
      <div className="px-4">
        <h3 className="mb-3">Conteúdos</h3>
        <div className="space-y-3">
          {articles.map((a, i) => (
            <div key={i} className="bg-card rounded-2xl p-4 shadow-sm border border-border/50 flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center shrink-0">
                <BookOpen className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{a.title}</p>
                <p className="text-[10px] text-muted-foreground">{a.tag} · {a.mins} min leitura</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
